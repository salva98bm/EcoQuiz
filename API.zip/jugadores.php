<?php 
    include "config.php";
    include "utils.php";
    $dbConn = connect($db);

    # MÉTODO GET (CONSULTA)
    if($_SERVER['REQUEST_METHOD'] == 'GET'){
        # SI SE MANDA UN ID, SE MUESTRA EL REGISTRO CORRESPONDIENTE
        if(isset($_GET['idJugador'])){
            $sql = $dbConn->prepare("SELECT * FROM jugadores WHERE idJugador=:idJugador");
            $sql->bindValue(':idJugador', $_GET['idJugador']);
            $sql->execute();
            header("HTTP/1.1 200 OK");
            echo json_encode($sql->fetch(PDO::FETCH_ASSOC));
            exit();
        }
        # SI NO SE MANDA UN ID, SE MUESTRAN TODOS LOS REGISTROS
        else{
            $sql = $dbConn->prepare("SELECT * FROM jugadores ORDER BY puntuacionJugador DESC");
            $sql->execute();
            $sql->setFetchMode(PDO::FETCH_ASSOC);
            header("HTTP/1.1 200 OK");
            echo json_encode($sql->fetchAll());
            exit();
        }
    }

    # MÉTODO POST (AGREGAR REGISTRO)
    if($_SERVER['REQUEST_METHOD'] == 'POST'){
        $sql = "INSERT INTO jugadores VALUES (null, '".$_POST['nombreJugador']."', '".$_POST['claveJugador']."', '".$_POST['puntuacionJugador']."', '".$_POST['avatarJugador']."')";
        $statement = $dbConn->prepare($sql);
        $statement->execute();
        $postId = $dbConn->lastInsertId();
        if($postId){
            $input['idJugador'] = $postId;
            header("HTTP/1.1 200 OK");
            echo json_encode($input);
            exit();
            }
    }

    # MÉTODO DELETE
    if($_SERVER['REQUEST_METHOD'] == 'DELETE'){
        $idJugador = $_GET['idJugador'];
        $statement = $dbConn->prepare("DELETE FROM jugadores WHERE idJugador=:idJugador");
        $statement->bindValue(':idJugador', $idJugador);
        $statement->execute();
        header("HTTP/1.1 200 OK");
        exit();
    }

    # MÉTODO PUT (MODIFICAR REGISTRO)
    if($_SERVER['REQUEST_METHOD'] == 'PUT'){
        $sql = "UPDATE jugadores SET nombreJugador='".$_GET['nombreJugador']."', claveJugador='".$_GET['claveJugador']."', puntuacionJugador='".$_GET['puntuacionJugador']."', avatarJugador='".$_GET['avatarJugador']."' WHERE idJugador=".$_GET['idJugador'];
        $statement = $dbConn->prepare($sql);
        $statement->execute();
        header("HTTP/1.1 200 OK");
        exit();
    }
    header("HTTP/1.1 400 Bad Requeest")
?>