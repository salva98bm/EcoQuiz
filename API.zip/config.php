<?php
$db = [
    'host' => 'localhost',
    'username' => 'rest',
    'password' => 'Studium2020;',
    'db' => 'ecoquizz'
];
?>
