<?php 
    include "config.php";
    include "utils.php";
    $dbConn = connect($db);

    # MÉTODO GET (CONSULTA)
    if($_SERVER['REQUEST_METHOD'] == 'GET'){
        # SI SE MANDA UN ID, SE MUESTRA EL REGISTRO CORRESPONDIENTE
        if(isset($_GET['idPregunta'])){
            $sql = $dbConn->prepare("SELECT * FROM preguntas WHERE idPregunta=:idPregunta");
            $sql->bindValue(':idPregunta', $_GET['idPregunta']);
            $sql->execute();
            header("HTTP/1.1 200 OK");
            echo json_encode($sql->fetch(PDO::FETCH_ASSOC));
            exit();
        }
        # SI NO SE MANDA UN ID, SE MUESTRAN TODOS LOS REGISTROS
        else{
            $sql = $dbConn->prepare("SELECT * FROM preguntas ORDER BY RAND()");
            $sql->execute();
            $sql->setFetchMode(PDO::FETCH_ASSOC);
            header("HTTP/1.1 200 OK");
            echo json_encode($sql->fetchAll());
            exit();
        }
    }

    # MÉTODO POST (AGREGAR REGISTRO)
    if($_SERVER['REQUEST_METHOD'] == 'POST'){
        $sql = "INSERT INTO preguntas VALUES (null, '".$_POST['enunciadoPregunta']."', '".$_POST['respuesta1Pregunta']."', '".$_POST['respuesta2Pregunta']."')";
        $statement = $dbConn->prepare($sql);
        $statement->execute();
        $postId = $dbConn->lastInsertId();
        if($postId){
            $input['idPregunta'] = $postId;
            header("HTTP/1.1 200 OK");
            echo json_encode($input);
            exit();
            }
    }

    # MÉTODO DELETE
    if($_SERVER['REQUEST_METHOD'] == 'DELETE'){
        $idPregunta = $_GET['idPregunta'];
        $statement = $dbConn->prepare("DELETE FROM preguntas WHERE idPregunta=:idPregunta");
        $statement->bindValue(':idPregunta', $idPregunta);
        $statement->execute();
        header("HTTP/1.1 200 OK");
        exit();
    }

    # MÉTODO PUT (MODIFICAR REGISTRO)
    if($_SERVER['REQUEST_METHOD'] == 'PUT'){
        $sql = "UPDATE preguntas SET enunciadoPregunta='".$_GET['enunciadoPregunta']."',
         respuesta1Pregunta='".$_GET['respuesta1Pregunta']."',
          respuesta2Pregunta='".$_GET['respuesta2Pregunta']."',
           respuesta3Pregunta='".$_GET['respuesta3Pregunta']."',
            respuesta4Pregunta='".$_GET['respuesta4Pregunta']."'
              WHERE idPregunta=".$_GET['idPregunta'];
        $statement = $dbConn->prepare($sql);
        $statement->execute();
        header("HTTP/1.1 200 OK");
        exit();
    }
    header("HTTP/1.1 400 Bad Requeest")
?>